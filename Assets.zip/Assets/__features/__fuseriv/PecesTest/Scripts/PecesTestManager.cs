using System.Collections.Generic;
using UnityEngine;

// ====================
// MANAGER PECES TEST
// Activa peces aleatorios, les da color y define qué colores valen
// ====================
public class PecesTestManager : MonoBehaviour
{
    // ====================
    // SPAWN
    // ====================
    [Header("Spawn")]
    [SerializeField] private string fishTag = "Orbe";
    [SerializeField] private int porcentajeMinimoActivos = 65;

    // ====================
    // COLORES QUE PUEDEN SALIR
    // ====================
    [Header("Colores que pueden aparecer")]
    [SerializeField] private bool puedeSalirRosa = true;
    [SerializeField] private bool puedeSalirAmarillo = true;
    [SerializeField] private bool puedeSalirVerde = true;

    // ====================
    // COLORES DEL ENCARGO TEST
    // ====================
    [Header("Colores correctos del test")]
    [SerializeField] private bool rosaActivo = true;
    [SerializeField] private bool amarilloActivo = false;
    [SerializeField] private bool verdeActivo = false;

    // ====================
    // PECES
    // ====================
    private Pez[] todosLosPeces;

    // ====================
    // INICIO
    // ====================
    private void Start()
    {
        BuscarPeces();
        ActivarPecesAleatorios();
    }

    // ====================
    // BUSCAR
    // ====================
    private void BuscarPeces()
    {
        GameObject[] objetos = GameObject.FindGameObjectsWithTag(fishTag);
        List<Pez> lista = new List<Pez>();

        for (int i = 0; i < objetos.Length; i++)
        {
            Pez pez = objetos[i].GetComponent<Pez>();

            if (pez != null)
            {
                lista.Add(pez);
            }
        }

        todosLosPeces = lista.ToArray();
    }

    // ====================
    // ACTIVAR
    // ====================
    public void ActivarPecesAleatorios()
    {
        if (todosLosPeces == null || todosLosPeces.Length == 0)
            return;

        int totalPeces = todosLosPeces.Length;
        int minimoActivos = (totalPeces * porcentajeMinimoActivos) / 100;

        if (minimoActivos < 1)
        {
            minimoActivos = 1;
        }

        int cantidadActivos = Random.Range(minimoActivos, totalPeces + 1);

        List<int> indicesDisponibles = new List<int>();
        for (int i = 0; i < totalPeces; i++)
        {
            indicesDisponibles.Add(i);
            todosLosPeces[i].gameObject.SetActive(false);
        }

        for (int i = 0; i < cantidadActivos; i++)
        {
            int indiceRandomLista = Random.Range(0, indicesDisponibles.Count);
            int indicePez = indicesDisponibles[indiceRandomLista];

            indicesDisponibles.RemoveAt(indiceRandomLista);

            todosLosPeces[indicePez].gameObject.SetActive(true);
            todosLosPeces[indicePez].ConfigurarPez(ObtenerColorAleatorio());
        }
    }

    // ====================
    // COLOR RANDOM
    // ====================
    private ColorPez ObtenerColorAleatorio()
    {
        List<ColorPez> coloresDisponibles = new List<ColorPez>();

        if (puedeSalirRosa)
        {
            coloresDisponibles.Add(ColorPez.Rosa);
        }

        if (puedeSalirAmarillo)
        {
            coloresDisponibles.Add(ColorPez.Amarillo);
        }

        if (puedeSalirVerde)
        {
            coloresDisponibles.Add(ColorPez.Verde);
        }

        if (coloresDisponibles.Count == 0)
        {
            return ColorPez.Rosa;
        }

        int indice = Random.Range(0, coloresDisponibles.Count);
        return coloresDisponibles[indice];
    }

    // ====================
    // COLOR CORRECTO
    // ====================
    public bool EsColorCorrecto(ColorPez color)
    {
        if (color == ColorPez.Rosa && rosaActivo)
        {
            return true;
        }

        if (color == ColorPez.Amarillo && amarilloActivo)
        {
            return true;
        }

        if (color == ColorPez.Verde && verdeActivo)
        {
            return true;
        }

        return false;
    }
}