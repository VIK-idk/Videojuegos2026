using UnityEngine;

// ====================
// PICKUP TEST
// Detecta si el jugador recoge el pez y comprueba si su color vale
// ====================
public class PezPickupTest : MonoBehaviour
{
    // ====================
    // TRIGGER
    // ====================
    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        Pez pez = GetComponent<Pez>();
        PecesTestManager manager = FindFirstObjectByType<PecesTestManager>();

        if (pez == null || manager == null)
            return;

        bool esCorrecto = manager.EsColorCorrecto(pez.GetColorPez());

        if (esCorrecto)
        {
            Debug.Log("Pez correcto recogido. Color: " + pez.GetColorPez() + " | ID: " + pez.GetColorId());
        }
        else
        {
            Debug.Log("Pez incorrecto recogido. Color: " + pez.GetColorPez() + " | ID: " + pez.GetColorId());
        }

        Destroy(gameObject);
    }
}